package main

import (
	"fmt"
	"insurance"
	"time"
	//"strconv"
	//"github.com/gin-gonic/gin"
)

var Riskdata = `
Name,ID,Include,Deleted,Limit
Risk1,1,1,0,25
Risk2,2,1,0,22
Risk3,3,1,0,21
Risk4,4,1,0,15
`

type HeaderMap map[string]int

/*
type File struct {
	path      string
	headerMap HeaderMap
	risks     insure.Risks
	csvReader *csv.Reader
	fields    []string
}*/

func main() {

	//debug := zerolog.New(os.Stdout).With().Timestamp().Caller().Logger()
	//log := zerolog.New(os.Stdout).With().Logger()

	//ac := accounting.Accounting{Symbol: "$", Precision: 2, Thousand: ",", Decimal: "."} //Premium Formatter, Pennies ., Thousand Separator ,

	now := time.Now()
	var po insurance.PolicyOptions
	//var lo insurance.LineOptions
	//var ro insurance.RiskOptions
	//var to insurance.TransactOptions

	/*
		policy := insurance.NewPolicy("SamplePolicyNumber",
			po.SetEffectiveDate(now),
			po.SetExpirationDate(addMonth(now, 12)),
			po.AddLine(
				insurance.NewLine("Line1",
					lo.SetTypeLOB("CAuto"),
					lo.SetTermPremium(decimal.NewFromInt(120)),
					lo.SetPriorTermPremium(decimal.NewFromInt(110)),
					lo.AddCoverage(insurance.NewCoverage(true)),
					lo.AddRisk(insurance.NewRisk("Risk1",
						ro.AddCoverage(insurance.NewCoverage(true)),
					)),
					lo.AddRisk(insurance.NewRisk("Risk2",
						ro.AddCoverage(insurance.NewCoverage(true)),
					)),
					lo.AddLocation(insurance.NewLocation("Location1")),
				),
			),
			po.AddLine(insurance.NewLine("Line2")),
			po.AddTransaction(insurance.NewTransaction("New", now, addDay(now, 0), addMonth(now, 12))),
			//	to.SetDaysInTerm(1.0),
			po.AddTransaction(insurance.NewTransaction("Endorse", now, addDay(now, 15), addMonth(now, 12))),
		)*/

	policy := insurance.NewPolicy("SamplePolicyNumber",
		po.SetEffectiveDate(now),
		po.SetExpirationDate(addMonth(now, 12)),
		po.GetLines(), //Please review
	)

	fmt.Printf("%s\n", policy)

} //func main

func addMonth(t time.Time, month int) time.Time {
	return t.AddDate(0, month, 0)
}

func addDay(t time.Time, day int) time.Time {
	return t.AddDate(0, 0, day)
}

/*
	func add12Month(t time.Time) time.Time {
		return t.AddDate(0, 12, 0)
	}

	func add6Month(t time.Time) time.Time {
		return t.AddDate(0, 6, 0)
	}
	func addYear(t time.Time) time.Time {
	return t.AddDate(1, 0, 0)
}
*/

/*
func main() {
	records := [][]string{
		{"first_name", "last_name", "username"},
		{"Rob", "Pike", "rob"},
		{"Ken", "Thompson", "ken"},
		{"Robert", "Griesemer", "gri"},
	}

	w := csv.NewWriter(os.Stdout)
	w.WriteAll(records) // calls Flush internally

	if err := w.Error(); err != nil {
		log.Fatalln("error writing csv:", err)
	}

*/
