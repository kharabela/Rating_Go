package insurance

import (
	"fmt"
	"time"
)

type Transactions []*Transaction

type Transaction struct {
	Id             string
	TypeCode       string
	ImageType      string
	Status         string
	State          string
	EffectiveDate  time.Time
	CreatedDate    time.Time
	ExpirationDate time.Time
	IssuedDate     time.Time
	TermFactor     float64
}

type TransactOptions func(*Transaction)

func (TransactOptions) SetDaysInTerm(TermFactor float64) TransactOptions {
	return func(t *Transaction) {
		t.TermFactor = TermFactor
	}
}

func NewTransaction(id string, createdt time.Time, effdt time.Time, expdt time.Time) *Transaction {
	return &Transaction{Id: id, CreatedDate: createdt, EffectiveDate: effdt, ExpirationDate: expdt}
}

func (tx Transaction) StringWithTabs(tabs string) string {
	return fmt.Sprintf("%sTransaction ID: %s\n"+
		"%s  Created Date:%s\n"+
		"%s  Effective Date:%s\n"+
		"%s  Expiration Date:%s",
		tabs, tx.Id,
		tab, tx.CreatedDate.Format(time.RFC3339),
		tab, tx.EffectiveDate.Format(time.RFC3339),
		tab, tx.ExpirationDate.Format(time.RFC3339))
}
