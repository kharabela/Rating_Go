package insurance

const shortFormTime = "2006-01-02"
