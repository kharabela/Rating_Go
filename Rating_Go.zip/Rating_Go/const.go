package insurance

const tab = "  "
