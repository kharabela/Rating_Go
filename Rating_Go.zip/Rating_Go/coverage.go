package insurance

import (
	"fmt"
	"strings"
	"time"

	"github.com/shopspring/decimal"
)

type Coverages []*Coverage
type Coverage struct {
	indicator           bool
	included            bool
	deleted             bool
	modified            bool
	deductible          int
	level               string // level-[Risk/Line]
	coverageType        string //coverageType-[Premium,Tax,Fees,Surcharge],
	code                string
	formulae            string
	statCode            string
	currentLimit        string
	priorLimit          string
	baseRate            string
	ilf                 string
	addedDate           time.Time
	effectiveDate       time.Time
	expirationDate      time.Time
	deletedDate         time.Time
	termPremium         decimal.Decimal
	priorTermPremium    decimal.Decimal
	changePremium       decimal.Decimal
	writtenPremium      decimal.Decimal
	priorWrittenPremium decimal.Decimal
	termFactor          decimal.Decimal
	drf                 decimal.Decimal
	stringBuilder       strings.Builder
	//WrittenPremium=Prior Written + Term Charge {[Term Premium -Prior Term Premium] *DRF}
	//For NB , Prior Written & Prior Term Premium[WrittenPremium-ChangePremium] = 0
}

func NewCoverage(indicator bool) *Coverage {
	return &Coverage{indicator: indicator}
}

func (c Coverage) StringWithTabs(tabs string) (s string) {
	return fmt.Sprintf("%sCoverage: %t", tabs+tab, c.indicator)
}

func (c *Coverage) ShowCalc() string {

	return fmt.Sprintf("%v [%v] = (%v)", c.code, c.termPremium, c.formulae)
}

func (c *Coverage) CalculatePremium() decimal.Decimal {
	var BaseRate, ILF decimal.Decimal
	DRF, err := decimal.NewFromString("1")
	if err != nil {
		fmt.Println(err)
	}

	c.stringBuilder.Reset()
	c.formulae = ""
	c.drf = DRF

	if c.code == "BodilyInjury" {
		BaseRate, _ = decimal.NewFromString(c.baseRate)
		c.stringBuilder.WriteString("Base Rate ")
		c.stringBuilder.WriteString("[" + BaseRate.String() + "]")

		ILF, _ = decimal.NewFromString(c.ilf)
		c.stringBuilder.WriteString(" * ")
		c.stringBuilder.WriteString("ILF ")
		c.stringBuilder.WriteString("[" + ILF.String() + "]")
	}

	if c.code == "Comprehensive" {
		BaseRate, _ = decimal.NewFromString(c.baseRate)
		c.stringBuilder.WriteString("Base Rate ")
		c.stringBuilder.WriteString("[" + BaseRate.String() + "]")

		ILF, _ = decimal.NewFromString(c.ilf)
		c.stringBuilder.WriteString(" * ")
		c.stringBuilder.WriteString("ILF ")
		c.stringBuilder.WriteString("[" + ILF.String() + "]")
	}

	if c.code == "Collision" {
		BaseRate, _ = decimal.NewFromString(c.baseRate)
		c.stringBuilder.WriteString("Base Rate ")
		c.stringBuilder.WriteString("[" + BaseRate.String() + "]")

		ILF, _ = decimal.NewFromString(c.ilf)
		c.stringBuilder.WriteString(" * ")
		c.stringBuilder.WriteString("ILF ")
		c.stringBuilder.WriteString("[" + ILF.String() + "]")
	}

	if c.code == "PersonalInjuryProtection" {
		BaseRate, _ = decimal.NewFromString(c.baseRate)
		c.stringBuilder.WriteString("Base Rate ")
		c.stringBuilder.WriteString("[" + BaseRate.String() + "]")

		ILF, _ = decimal.NewFromString(c.ilf)
		c.stringBuilder.WriteString(" * ")
		c.stringBuilder.WriteString("ILF ")
		c.stringBuilder.WriteString("[" + ILF.String() + "]")
	}

	c.formulae = c.stringBuilder.String()
	c.termPremium = BaseRate.Mul(ILF)
	c.changePremium = c.termPremium.Sub(c.priorTermPremium).Mul(DRF) //Term Charge {[Term Premium - Prior Term Premium] *DRF}
	c.writtenPremium = c.priorWrittenPremium.Add(c.changePremium)    //WrittenPremium=Prior Written + Term Charge {[Term Premium - Prior Term Premium] *DRF}
	return c.termPremium
}
