package insurance

import (
	"fmt"
	"strings"
)

type Locations []*Location
type Location struct {
	Indicator        bool
	Address1         string
	City             string
	State            string
	ZIPCode          string
	FullAddress      string
	Type             string
	StringBuilderLoc strings.Builder
}

func NewLocation(addr string) *Location {
	return &Location{Address1: addr}
}

func (l Location) StringWithTabs(tabs string) (s string) {
	return fmt.Sprintf("%sLocation: %s", tabs+tab, l.Address1)
}

func (l *Location) ShowLocation() string {
	l.StringBuilderLoc.Reset()
	l.StringBuilderLoc.WriteString(l.Address1)
	l.StringBuilderLoc.WriteString(" ")
	l.StringBuilderLoc.WriteString(l.City)
	l.StringBuilderLoc.WriteString(" ")
	l.StringBuilderLoc.WriteString(l.State)
	l.StringBuilderLoc.WriteString(" ")
	l.StringBuilderLoc.WriteString(l.ZIPCode)
	l.FullAddress = l.StringBuilderLoc.String()
	return fmt.Sprintf("[%v] = (%v)", "Address ", l.FullAddress)
}
