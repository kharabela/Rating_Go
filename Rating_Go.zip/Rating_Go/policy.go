package insurance

import (
	"encoding/csv"
	"fmt"
	"io"
	"log"
	"os"
	"regexp"
	"time"

	"github.com/rs/zerolog"
)

type HeaderMap map[string]int

type File struct {
	path      string
	headerMap HeaderMap
	lines     Lines
	csvReader *csv.Reader
	fields    []string
}

func NewFile(filepath string) *File {
	return &File{
		path:  filepath,
		lines: make(Lines, 0),
	}
}

func (file File) get(col string) (value string, err error) {
	index, ok := file.headerMap[col]
	if !ok {
		err = fmt.Errorf("file does not contain column '%s'", col)
		goto end
	}
	if index >= len(file.fields) {
		log.Printf("Only %d fields; not enough to have a %d field '%s'",
			len(file.fields),
			index,
			col,
		)
		goto end
	}
	value = file.fields[index]
end:
	return value, err
}

func (file *File) read() (err error) {
	if file.headerMap == nil {
		err = file.readHeader()
	}
	if err != nil {
		goto end
	}
	file.fields, err = file.csvReader.Read()
end:
	return err
}

// ReadHeader add mapping: Column/property name --> record index
func (file *File) readHeader() (err error) {
	file.headerMap = make(HeaderMap)
	file.fields, err = file.csvReader.Read()
	if err != nil {
		goto end
	}
	for i, v := range file.fields {
		file.headerMap[v] = i
	}
end:
	return err
}

func (file *File) open() (*os.File, error) {
	// Load a csv file.
	f, err := os.Open(file.path)
	if err != nil {
		goto end
	}
	// Create a new reader.
	file.csvReader = csv.NewReader(f)
end:
	return f, err
}

type Policy struct {
	number         string //GUID
	effectiveDate  time.Time
	expirationDate time.Time
	lines          Lines
	transactions   Transactions
}

type PolicyOptions func(*Policy)

func (PolicyOptions) SetEffectiveDate(d time.Time) PolicyOptions {
	return func(p *Policy) {
		p.effectiveDate = d
	}
}

func (PolicyOptions) SetExpirationDate(d time.Time) PolicyOptions {
	return func(p *Policy) {
		p.expirationDate = d
	}
}

func NewPolicy(number string, opts ...PolicyOptions) *Policy {
	p := &Policy{
		number:       number,
		lines:        make([]*Line, 0),
		transactions: make([]*Transaction, 0),
	}
	for _, opt := range opts {
		opt(p)
	}
	return p
}

func (PolicyOptions) AddLine(line *Line) PolicyOptions {
	//lines := readLineObjectsCSVFile("Objects/Line.csv")
	return func(p *Policy) {
		p.lines = append(p.lines, line)
	}
}

/*
P.line = append(P.line, Line{}) // add an empty line element
fmt.Println(len(P.line))        // now there's one line
P.line[0].ID = "line1"  */

func (PolicyOptions) GetLines() PolicyOptions { //func (file *File) GetLines(policy *Policy) (err error) {
	return func(p *Policy) {
		/*
			lines := readLineObjectsCSVFile("Objects/Line.csv")
			for _, lines := range lines {
				//p.lines = append(p.lines, lines)
				fmt.Println("Line ID -" + lines.TypeLOB)

			}*/ //The comment code works and brings desired output
		//	p.lines = append(p.lines, line) //Unable to make this work
	}

}

func (PolicyOptions) AddTransaction(tx *Transaction) PolicyOptions {
	return func(p *Policy) {
		p.transactions = append(p.transactions, tx)
	}
}

var reCompressNewLines = regexp.MustCompile(`\n+`)

func (p Policy) String() (s string) {
	s = fmt.Sprintf(
		"Policy:\n"+
			"%sNumber: %s\n"+
			"%sEffective Date: %s\n"+
			"%sExpiration Date: %s\n"+
			"%sLines:\n%s"+
			"%sTransactions:\n%s",
		tab, p.number,
		tab, p.effectiveDate.Format(shortFormTime),
		tab, p.expirationDate.Format(shortFormTime),

		tab, stringWithTabs(p.lines, tab+tab),
		tab, stringWithTabs(p.transactions, tab+tab),
	)
	return reCompressNewLines.ReplaceAllLiteralString(s, "\n")
}

func readLineObjectsCSVFile(filePath string) (lines []Line) {
	isFirstRow := true
	headerMap := make(map[string]int)

	// Load a csv file.
	f, _ := os.Open(filePath)

	// Create a new reader.
	r := csv.NewReader(f)
	for {
		// Read row
		record, err := r.Read()
		defer f.Close()

		// Stop at EOF.
		if err == io.EOF {
			break
		}

		checkError("Some other error occurred", err)

		// Handle first row case
		if isFirstRow {
			isFirstRow = false

			// Add mapping: Column/property name --> record index
			for i, v := range record {
				headerMap[v] = i
			}

			// Skip next code
			continue
		}

		// Create new coverage and add to persons array
		lines = append(lines, Line{
			TypeLOB: record[headerMap["TypeLOB"]],
			Id:      record[headerMap["Id"]],
		})
	}
	return

}

func checkError(message string, err error) {
	// Error Logging
	if err != nil {
		//log.Fatal(message, err)
		log := zerolog.New(os.Stdout).With().Logger()
		log.Debug().Str(" checkError %s ", message)
	}
}
