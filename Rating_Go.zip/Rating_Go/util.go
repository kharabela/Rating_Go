package insurance

import (
	"strings"
)

type stringerWithTabs interface {
	StringWithTabs(string) string
}

func stringWithTabs[S ~[]E, E stringerWithTabs](slice S, tabs string) (s string) {
	if len(slice) == 0 {
		return "\n"
	}
	sb := strings.Builder{}
	for _, ele := range slice {
		sb.WriteString(ele.StringWithTabs(tabs))
		sb.WriteByte('\n')
	}
	return sb.String()
}

// strDelimit converts 'ABCDEFG' to, for example, 'A,BCD,EFG'
func strDelimit(str string, sepstr string, sepcount int) string {
	pos := len(str) - sepcount
	for pos > 0 {
		str = str[:pos] + sepstr + str[pos:]
		pos = pos - sepcount
	}
	return str
}
