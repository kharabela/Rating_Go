package insurance

type OptionSetter func()
