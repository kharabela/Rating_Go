package insurance

import (
	"encoding/csv"
	"fmt"
	"io"
	"log"
	"os"

	"github.com/shopspring/decimal"
)

/*
type HeaderMap map[string]int

	type File struct {
		path      string
		headerMap HeaderMap
		lines     Lines
		csvReader *csv.Reader
		fields    []string
	}

	func NewFile(filepath string) *File {
		return &File{
			path:  filepath,
			lines: make(Lines, 0),
		}
	}

	func (file File) get(col string) (value string, err error) {
		index, ok := file.headerMap[col]
		if !ok {
			err = fmt.Errorf("file does not contain column '%s'", col)
			goto end
		}
		if index >= len(file.fields) {
			log.Printf("Only %d fields; not enough to have a %d field '%s'",
				len(file.fields),
				index,
				col,
			)
			goto end
		}
		value = file.fields[index]

end:

		return value, err
	}

func (file *File) read() (err error) {
	if file.headerMap == nil {
		err = file.readHeader()
	}
	if err != nil {
		goto end
	}
	file.fields, err = file.csvReader.Read()
end:
	return err
}



// ReadHeader add mapping: Column/property name --> record index
func (file *File) readHeader() (err error) {
	file.headerMap = make(HeaderMap)
	file.fields, err = file.csvReader.Read()
	if err != nil {
		goto end
	}
	for i, v := range file.fields {
		file.headerMap[v] = i
	}
end:
	return err
}

func (file *File) open() (*os.File, error) {
	// Load a csv file.
	f, err := os.Open(file.path)
	if err != nil {
		goto end
	}
	// Create a new reader.
	file.csvReader = csv.NewReader(f)
end:
	return f, err
}
*/

type Lines []*Line

type Line struct {
	Id                  string
	TypeLOB             string
	coverages           Coverages
	TermPremium         decimal.Decimal
	PriorTermPremium    decimal.Decimal
	ChangePremium       decimal.Decimal
	WrittenPremium      decimal.Decimal
	PriorWrittenPremium decimal.Decimal
	risks               Risks
	locations           Locations
}

type LineOptions func(*Line)

/*func GetLines(opts ...LineOptions) *Line {  //	func (file *File) ReadRisks(line *insure.Line) (err error)

}*/

func (file *File) GetLines(policy *Policy) (err error) {
	var f *os.File
	var recNo int
	var line *Line

	f, err = file.open()
	if err != nil {
		goto end
	}
	//defer Close(f, WarnOnError) //don't know why this errors
	defer f.Close()
	recNo = 0
	for {
		recNo++
		err = file.read()
		if err == io.EOF {
			err = nil
			goto end
		}
		if err != nil {
			log.Printf("Error reading line %d; %s", recNo, err.Error())
			continue
		}
		//risk, err = file.risk()
		line, err = file.line()
		if err != nil {
			log.Printf("Error adding risk from record #%d; %s", recNo, err.Error())
			continue
		}
		//line.AddRisk(risk)
		policy.AddLine(line)
	}
end:
	return err
}

func (policy *Policy) AddLine(line *Line) *Policy {
	policy.lines = append(policy.lines, line)
	return policy
}

/*
func (l *Line) AddRisk(risk *Risk) *Line {
	l.risks = append(l.risks, risk)
	return l
}*/

func (file *File) line() (line *Line, err error) {
	var field string

	//opts := insurance.Line{}
	opts := Line{}
	opts.TypeLOB, err = file.get("Name")
	if err != nil {
		field = "Line"
		goto end
	}
	opts.Id, err = file.get("ID")
	if err != nil {
		field = "ID"
		goto end
	}
	//risk = insure.NewRisk(opts.ID, &opts)
	//line = NewLine(opts.Id, &opts)

end:
	if err != nil {
		err = fmt.Errorf("failed to get record's '%s' field",
			field,
		)
	}
	return line, err
}

/*

func NewRisk(id string, opts *RiskOpts) *Risk {
	return &Risk{
		id:                   id,
		guid:                 opts.GUID,
		indicator:            opts.Indicator,
		included:             opts.Include,
		deleted:              opts.Deleted,
		limit:                opts.Limit,
		associatedLocationID: opts.AssociatedLocationID,
		stringBuilderRisk:    opts.StringBuilderRisk,
		coverages:            nil,
	}
}*/

func NewLine(Id string, opts ...LineOptions) *Line {
	l := &Line{
		Id:        Id,
		risks:     make([]*Risk, 0),
		coverages: make([]*Coverage, 0),
		locations: make([]*Location, 0),
	}

	for _, opt := range opts {
		opt(l)
	}

	return l
}

func (LineOptions) SetTypeLOB(TypeLOB string) LineOptions {
	return func(l *Line) {
		l.TypeLOB = TypeLOB
	}
}

func (LineOptions) SetTermPremium(TermPremium decimal.Decimal) LineOptions {
	return func(l *Line) {
		l.TermPremium = TermPremium
	}
}

func (LineOptions) SetPriorTermPremium(PriorTermPremium decimal.Decimal) LineOptions {
	return func(l *Line) {
		l.PriorTermPremium = PriorTermPremium
	}
}

func (LineOptions) SetChangePremium(ChangePremium decimal.Decimal) LineOptions {
	return func(l *Line) {
		l.ChangePremium = ChangePremium
	}
}

func (LineOptions) SetWrittenPremium(WrittenPremium decimal.Decimal) LineOptions {
	return func(l *Line) {
		l.WrittenPremium = WrittenPremium
	}
}

func (LineOptions) SetPriorWrittenPremium(PriorWrittenPremium decimal.Decimal) LineOptions {
	return func(l *Line) {
		l.PriorWrittenPremium = PriorWrittenPremium
	}
}

func (LineOptions) AddCoverage(coverage *Coverage) LineOptions {
	return func(l *Line) {
		l.coverages = append(l.coverages, coverage)
	}
}

func (LineOptions) AddRisk(risk *Risk) LineOptions {
	return func(l *Line) {
		l.risks = append(l.risks, risk)
	}
}

func (LineOptions) AddLocation(location *Location) LineOptions {
	return func(l *Line) {
		l.locations = append(l.locations, location)
	}
}

func (l Line) StringWithTabs(tabs string) (s string) {
	return fmt.Sprintf("%sLine: %s\n"+
		"%sCoverages:\n%s"+
		"%sRisks:\n%s"+
		"%sLocations:\n%s",
		tabs, l.Id,
		tabs+tab, stringWithTabs(l.coverages, tabs+tab),
		tabs+tab, stringWithTabs(l.risks, tabs+tab),
		tabs+tab, stringWithTabs(l.locations, tabs+tab),
	)
}

/*
func readLineObjectsCSVFile(filePath string) (lines []Line) {
	isFirstRow := true
	headerMap := make(map[string]int)

	// Load a csv file.
	f, _ := os.Open(filePath)

	// Create a new reader.
	r := csv.NewReader(f)
	for {
		// Read row
		record, err := r.Read()
		defer f.Close()

		// Stop at EOF.
		if err == io.EOF {
			break
		}

		checkError("Some other error occurred", err)

		// Handle first row case
		if isFirstRow {
			isFirstRow = false

			// Add mapping: Column/property name --> record index
			for i, v := range record {
				headerMap[v] = i
			}

			// Skip next code
			continue
		}

		// Create new coverage and add to persons array
		lines = append(lines, Line{
			TypeLOB: record[headerMap["TypeLOB"]],
			Id:      record[headerMap["Id"]],
		})
	}
	return

}
*/

func readRiskObjectsCSVFile(filePath string) (risks []Risk) {
	isFirstRow := true
	headerMap := make(map[string]int)

	// Load a csv file.
	f, _ := os.Open(filePath)

	// Create a new reader.
	r := csv.NewReader(f)
	for {
		// Read row
		record, err := r.Read()
		defer f.Close()

		// Stop at EOF.
		if err == io.EOF {
			break
		}

		checkError("Some other error occurred", err)

		// Handle first row case
		if isFirstRow {
			isFirstRow = false

			// Add mapping: Column/property name --> record index
			for i, v := range record {
				headerMap[v] = i
			}

			// Skip next code
			continue
		}

		// Create new coverage and add to persons array
		risks = append(risks, Risk{
			GUID: record[headerMap["Name"]],
			Id:   record[headerMap["ID"]],
		})
	}
	return

}

func readRiskCoveragesCSVFile(filePath string) (coverages []Coverage) {
	isFirstRow := true
	headerMap := make(map[string]int)

	// Load a csv file.
	f, _ := os.Open(filePath)

	// Create a new reader.
	r := csv.NewReader(f)
	for {
		// Read row
		record, err := r.Read()
		defer f.Close()

		// Stop at EOF.
		if err == io.EOF {
			break
		}

		checkError("Some other error occurred", err)

		// Handle first row case
		if isFirstRow {
			isFirstRow = false

			// Add mapping: Column/property name --> record index
			for i, v := range record {
				headerMap[v] = i
			}

			// Skip next code
			continue
		}

		// Create new coverage and add to persons array
		coverages = append(coverages, Coverage{
			code:     record[headerMap["Name"]],
			baseRate: record[headerMap["BaseRate"]],
			ilf:      record[headerMap["ILF"]],
			statCode: record[headerMap["STATCode"]],
		})
	}
	return

}

/*
func checkError(message string, err error) {
	// Error Logging
	if err != nil {
		//log.Fatal(message, err)
		log := zerolog.New(os.Stdout).With().Logger()
		log.Debug().Str(" checkError %s ", message)
	}
}
*/
