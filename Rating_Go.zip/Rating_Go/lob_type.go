package insurance

type LOBType int

const (
	AutoLOBType = 1
	HomeLOBType = 2
)
